package com.example.aplikacja_sobolewski;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplikacjaSobolewskiApplicationTests {

    /**
     *
     */
    @Test
    void contextLoads() {
    }

}
