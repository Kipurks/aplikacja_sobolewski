package com.example.aplikacja_sobolewski.Film;

import com.example.aplikacja_sobolewski.Wypozyczenie.Wypozyczenie;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
public class Film {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public long Id;
    public String Title;
    public LocalDate Year;
    public String Author;
    public String Description;

    @OneToMany(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "id_Filmu")
    @JsonIgnore
    public List<Wypozyczenie> wypozyczenie;

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public long getId() {
        return Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public LocalDate getYear() {
        return Year;
    }

    public void setYear(LocalDate year) {
        Year = year;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String author) {
        Author = author;
    }

    public List<Wypozyczenie> getWypozyczenie() {
        return wypozyczenie;
    }

    public void setWypozyczenie(List<Wypozyczenie> wypozyczenie) {
        this.wypozyczenie = wypozyczenie;
    }

    @Override
    public String toString() {
        return "Film{" +
                "Id=" + Id +
                ", Title='" + Title + '\'' +
                ", Year=" + Year +
                ", Author='" + Author + '\'' +
                ", wypozyczenie=" + wypozyczenie +
                '}';
    }

    public Film() {
    }


}

