package com.example.aplikacja_sobolewski;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplikacjaSobolewskiApplication {

    public static void main(String[] args) {
        SpringApplication.run(AplikacjaSobolewskiApplication.class, args);
    }
}
